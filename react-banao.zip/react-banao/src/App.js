import './App.css';
import Navigation from './Components/Navigation';
import Top from './Components/Top';
import Content from './Components/Content';

function App() {
  return (
    <div className="App">
      <div className="desktop">
        <Navigation/>
        <Top/>
        <Content/>
      </div>
      
    </div>
  );
}

export default App;
