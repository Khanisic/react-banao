import React from 'react'
import {Modal} from 'react-bootstrap'
import './Modal.css'
import sign from '../Images/sign.png'
import google from '../Images/google.png'
import facebook from '../Images/facebook.png'
import {Form,Button} from 'react-bootstrap'

function Modals(props) {

    let typeOfSign = props.intype;
    let selectedSign;

    if(typeOfSign === "login"){
        selectedSign = 
        <div className="modal-outer ">
        <div className="modal-p mb-0">
            <p className="text-center">Let's learn, share & inspire each other with our 
            passion for computer engineering. Sign up now 🤘🏼</p></div>
        <div className="modal-inner">
            <div className="modal-left mx-auto mt-4 ml-5">
                <h3 className="mb-4">Sign In</h3>
                <Form inline className="mx-auto modal-form mb-4">
                    <div className="sign-form mb-3">
                        <input placeholder="Email">
                        </input>
                        <input placeholder="Password">
                        </input>
                        <i class="uil uil-eye"></i>
                        <button className="btn-signin my-3 px-1 py-2" >Sign In </button>
                        <button className="btn-social mt-2 mb-1 p-1">
                            <img className="mx-2 mb-1" src={facebook} alt="facebook"></img>Sign in with Facebook</button>
                        <button className="btn-social p-1" >
                            <img className="mx-2 mb-1" src={google} alt="google"></img>Sign in with Google</button>
                    </div>
                </Form>
                <p className="text-center mb-5">Forgot Password?</p>
            </div>
            <div className="modal-right ml-auto mr-5 mt-4">
                <p>Don’t have an account yet? <span>Create new for free!</span> </p>
                <img src={sign} alt="vector-image"></img>
            </div>
        </div>
    </div>
    }
    else{
        selectedSign = 
        <div className="modal-outer ">
        <div className="modal-p mb-0">
            <p className="text-center">Let's learn, share & inspire each other with our 
            passion for computer engineering. Sign up now 🤘🏼</p></div>
        <div className="modal-inner">
            <div className="modal-left mr-auto mt-4 ml-5">
                <h3 className="mb-4">Create Account</h3>
                <Form inline className="mx-auto modal-form mb-4">
                    <div className="sign-form-2 mb-3">
                        <div className="sign-form-sign">
                            <input placeholder="First Name">
                            </input>
                            <input placeholder="Last Name">
                            </input>
                        </div>
                            
                        <input placeholder="Email">
                        </input>
                        <input placeholder="Password">
                        </input>
                        <input password placeholder="Confirm Password">
                        </input>
                        <i class="uil uil-eye"></i>
                        <button className="btn-signin my-3 px-1 py-2" >Sign In </button>
                        <button className="btn-social mt-2 mb-1 p-1">
                            <img className="mx-2 mb-1" src={facebook} alt="facebook"></img>Sign in with Facebook</button>
                        <button className="btn-social p-1" >
                            <img className="mx-2 mb-1" src={google} alt="google"></img>Sign in with Google</button>
                    </div>
                </Form>
                <p className="text-center mb-5">Forgot Password?</p>
            </div>
            <div className="modal-right ml-auto mr-5 mt-4">
                <p>Already Have an account? <span>Sign in</span> </p>
                <img src={sign} alt="vector-image"></img>

                <p className="by-sign">By signing up, you agree to our Terms & conditions, Privacy policy</p>
            </div>
        </div>
    </div>
    }
    return (
        <Modal
            {...props}
            size="lg"
            aria-labelledby="contained-modal-title-vcenter"
            centered
            >
            {selectedSign}
        </Modal>
    );
};


export default Modals
