import React from 'react'
import bg from '../Images/top.png';
import bgMob from '../Images/topmob.png';
import join from '../Images/join.png';
import leave from '../Images/leave.png';
import './Top.css';


function Top() {



    const [show, setShow] = React.useState(false)
    let ele;

    if(show){
        ele = <div className="join-mob ml-auto mr-4 mt-4" onClick={ () => setShow(false)} >
                    Leave Group
                </div>
    }
    return (
        <div className="top-main">
            <div className="top">

            <div className="nav-mob">

                <div className="nav-mob-inner">
                    <i class="uil uil-arrow-left ml-2 mt-2"></i>
                    {ele}
                    <div className="join-mob ml-auto mr-4 mt-4 " onClick={ () => setShow(true)} style={{ display: show ? "none" : "block" }} >
                            Join Group
                    </div>
                </div>
                

            </div>

                <div className="top-text">
                    <h1>Computer Engineering</h1>
                    <p>142,765 Computer Engineers follow this</p>
                </div>
                <img className="top-desktop" src={bg} alt="not found"></img>
                <img className="top-mob" src={bgMob} alt="not found"></img>
                <div className="filter">

                </div>
            </div>
            
        </div>
    )
}

export default Top
