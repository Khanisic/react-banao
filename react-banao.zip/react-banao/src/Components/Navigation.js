import React from 'react'
import {Navbar,Form,Button,NavDropdown, Modal} from 'react-bootstrap';
import logo from '../Images/whole.png';
import './Navigation.css';
import Modals from './Modals'
import profilePic from '../Images/pfp4.png';

function Navigation() {

  const [modalShow, setModalShow] = React.useState(false);

  const [type, setType] = React.useState( { in : "" });

  const [pfp, setpfp] = React.useState(false);

  let ele;

  if(pfp){
    ele = 
    <>
    <div className="create-account mr-1">
      <img className="mr-2" src={profilePic} alt="pfp"></img>
      Siddharth Goyal </div>
                    <NavDropdown  id="basic-nav-dropdown" className="mr-5">
                      <NavDropdown.Item onClick={() => { setModalShow(true); login(); }}>Login</NavDropdown.Item>
                      <NavDropdown.Item onClick={() => { setModalShow(true);  sign(); }}>Sign In</NavDropdown.Item>
                      <NavDropdown.Item onClick={() => { setpfp(false)}}>Test Log Out</NavDropdown.Item>
                      
                    </NavDropdown>
                    </>
  }
  else{
    ele =
    <>
    <div className="create-account mr-0">Create Account. </div>
                    <NavDropdown title="It's free!" id="basic-nav-dropdown" className="mr-5">
                      <NavDropdown.Item onClick={() => { setModalShow(true); login(); }}>Login</NavDropdown.Item>
                      <NavDropdown.Item onClick={() => { setModalShow(true);  sign(); }}>Sign In</NavDropdown.Item>
                      <NavDropdown.Item onClick={() => { setpfp(true)}}>Test Sign In</NavDropdown.Item>
                    </NavDropdown>
                    </>
  } 

  const login = () =>{
    setType({ in : "login"})
  }
  const sign = () =>{
    setType({ in : "sign"})
  }
    return (
      <>
      <>
   
    </>
        <div className="nav-bar">
            <Navbar expand="lg" fixed="top">
              <Navbar.Brand href="#home">
                <img className="logo" src={logo} alt="not found">
                </img>
              </Navbar.Brand>
              <Navbar.Toggle aria-controls="basic-navbar-nav" />
              <Navbar.Collapse id="basic-navbar-nav">

                <Form inline className="mx-auto">
                  <div className="search">
                  <i class="uil uil-search mx-2"></i>
                    <input placeholder="Search for your favorite groups in ATG">
                    </input>
                  </div>
                </Form>
                {ele}
                    
              </Navbar.Collapse>
            </Navbar>

    <Modals
        show={modalShow}
        onHide={() => setModalShow(false)}
        intype={type.in}
    />
        </div>

        
        </>




    )
}

export default Navigation
