import React from 'react'
import pfp from '../Images/pfp1.png'
import pfp2 from '../Images/pfp2.png'
import pfp3 from '../Images/pfp3.png'
import pfp4 from '../Images/pfp4.png'
import bg1 from '../Images/bg1.png'
import bg2 from '../Images/bg2.png'
import bg3 from '../Images/bg3.png'
import './Posts.css'

function Posts() {
    return (
        <div className="Post-Desktop">
            <div >
                <div className="outer-box my-3">
                    <img src={bg1} alt="bg-img"></img>
                    <div className="inner-box">
                        <div className="type d-flex">
                            <i class="uil uil-pen px-1"></i>
                            <p>Article</p>
                        </div>
                        <div className="questions d-flex">
                            <p>What if famous brands had regular fonts? Meet RegulaBrands!</p>
                            <div className="ml-auto">
                                    
                                    <div class="dropdown">
                                    <i class="uil uil-elipsis-double-v-alt drop p-2"></i>
                                    <div class="dropdown-content mt-2">
                                        <a >Edit</a>
                                        <a >Report</a>
                                        <a >Option 3</a>
                                    </div>
                            </div>
                                    
                            </div>
                            
                        </div>
                        <div className="para">
                            <p>I’ve worked in UX for the better part of a decade. From now on, I plan to rei…</p>
                        </div>
                        <div className="my-4 foot d-flex">
                            <div className="pfp-box d-flex">
                                <img src={pfp} alt="pfp"></img>
                                <p>Sarthak Kamra</p>
                            </div>
                            <div className="views d-flex ml-auto mr-5">
                            <i class="uil uil-eye"></i>
                            <p>1.4k Views</p>
                            </div>
                            <div className="share  p-1">
                            <i class="uil uil-share p-1"></i>
                            </div>
                        </div>
                    </div>
                </div>
            </div>


            <div>
                <div className="outer-box my-3">
                    <img src={bg2} alt="bg-img"></img>
                    <div className="inner-box">
                        <div className="type d-flex">
                            <i class="uil uil-book-alt px-1"></i>
                            <p>Education</p>
                        </div>
                        <div className="questions d-flex">
                            <p>Tax Benefits for Investment under National Pension Scheme launched by Government</p>
                            <div className="ml-auto">
                                    
                                    <div class="dropdown">
                                    <i class="uil uil-elipsis-double-v-alt drop p-2"></i>
                                    <div class="dropdown-content mt-2">
                                        <a >Edit</a>
                                        <a >Report</a>
                                        <a >Option 3</a>
                                    </div>
                            </div>        
                            </div>
                        </div>
                        <div className="para">
                            <p>I’ve worked in UX for the better part of a decade. From now on, I plan to rei…</p>
                        </div>
                        <div className="my-4 foot d-flex">
                            <div className="pfp-box d-flex">
                                <img src={pfp2} alt="pfp"></img>
                                <p>Sarah West</p>
                            </div>
                            <div className="views d-flex ml-auto mr-5">
                            <i class="uil uil-eye"></i>
                            <p>1.4k Views</p>
                            </div>
                            <div className="share  p-1">
                            <i class="uil uil-share p-1"></i>
                            </div>
                        </div>
                    </div>
                </div>
            </div> 


            <div>
                <div className="outer-box my-3">
                    <img src={bg3} alt="bg-img"></img>
                    <div className="inner-box">
                        <div className="type d-flex">
                            <i class="uil uil-calender px-1"></i>
                            <p>Meetup</p>
                        </div>
                        <div className="questions d-flex">
                            <p>Finance & Investment Elite Social Mixer @Lujiazui</p>
                            <div className="ml-auto">
                                    
                                    <div class="dropdown">
                                    <i class="uil uil-elipsis-double-v-alt drop p-2"></i>
                                    <div class="dropdown-content mt-2">
                                        <a >Edit</a>
                                        <a >Report</a>
                                        <a >Option 3</a>
                                    </div>
                            </div>        
                            </div>
                        </div>
                        <div className="calender mb-2 d-flex">
                            <div className="calender-left d-flex">
                                <i class="uil uil-schedule mr-1"></i>
                                <p className="fw-bold">Fri, 12 Oct, 2018</p>    
                            </div>
                            <div className="calender-mid mx-auto d-flex">
                            <i class="uil uil-location-pin-alt"></i>
                            <p className="fw-bold">Ahmedabad, India</p>    
                            </div>

                        </div>

                        <p className="visit mx-auto">Visit Website</p>

                        <div className="my-4 foot d-flex">
                            <div className="pfp-box d-flex">
                                <img src={pfp3} alt="pfp"></img>
                                <p>Sarah West</p>
                            </div>
                            <div className="views d-flex ml-auto mr-5">
                            <i class="uil uil-eye"></i>
                            <p>1.4k Views</p>
                            </div>
                            <div className="share  p-1">
                            <i class="uil uil-share p-1"></i>
                            </div>
                        </div>
                    </div>
                </div>
            </div>


            <div>
                <div className="outer-box my-3">
                    <div className="inner-box">
                        <div className="type d-flex">
                            <i class="uil uil-bag-alt px-1"></i>
                            <p>Job</p>
                        </div>
                        <div className="questions d-flex">
                            <p>Software Developer</p>
                            <div className="ml-auto">
                                    
                                    <div class="dropdown">
                                    <i class="uil uil-elipsis-double-v-alt drop p-2"></i>
                                    <div class="dropdown-content mt-2">
                                        <a >Edit</a>
                                        <a >Report</a>
                                        <a >Option 3</a>
                                    </div>
                            </div>        
                            </div>
                        </div>
                        <div className="calender mb-2 d-flex">
                            <div className="calender-left d-flex">
                            <i class="uil uil-suitcase-alt"></i>
                                <p className="fw-bold">Innovaccer Analytics Private Ltd.</p>    
                            </div>
                            <div className="calender-mid mx-auto d-flex">
                            <i class="uil uil-location-pin-alt"></i>
                            <p className="fw-bold">Noida, India</p>    
                            </div>

                        </div>

                        <p className="apply mx-auto">Apply on Timesjobs</p>

                        <div className="my-4 foot d-flex">
                            <div className="pfp-box d-flex">
                                <img src={pfp4} alt="pfp"></img>
                                <p>Joseph Gray</p>
                            </div>
                            <div className="views d-flex ml-auto mr-5">
                            <i class="uil uil-eye"></i>
                            <p>1.4k Views</p>
                            </div>
                            <div className="share  p-1">
                            <i class="uil uil-share p-1"></i>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    )
}

export default Posts
