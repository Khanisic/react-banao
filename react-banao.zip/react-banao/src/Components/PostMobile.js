import React from 'react'
import './PostMobile.css'
import pfp from '../Images/pfp1.png'
import pfp2 from '../Images/pfp2.png'
import pfp3 from '../Images/pfp3.png'
import pfp4 from '../Images/pfp4.png'
import bg1 from '../Images/bg1.png'
import bg2 from '../Images/bg2.png'
import bg3 from '../Images/bg3.png'
import {Form} from 'react-bootstrap'
import google from '../Images/google.png'
import facebook from '../Images/facebook.png'
function PostMobile() {

    const [show, setShow] = React.useState(false);
    const [showLog, setShowLog] = React.useState(false);
    let ele;

    
        ele = <div className="modal-inner">
        <div className="modal-left mx-auto mt-4">
                    <div className="d-flex">
                        <h3 className="mb-4 mr-auto">Welcome Back</h3>
                        <i class="uil uil-times ml-auto cross" onClick={ () => setShowLog(false)}></i>
                    </div>
            <Form inline className=" mx-auto modal-form mb-4">
                <div className="sign-form mb-3">
                    <input placeholder="Email">
                    </input>
                    <input placeholder="Password">
                    </input>
                    <i class="uil uil-eye"></i>
                    <div className="d-flex my-3">
                                        <button className="btn-signin  px-3 py-2 mr-auto" >Sign In </button>
                                        <a className="ml-auto mt-2" onClick={ () => { setShow(true); setShowLog(false)} } >or, Create Account</a>
                                    </div>
                                    <button className="btn-social mt-2 mb-3 p-1">
                                        <img className="mx-2 mb-1" src={facebook} alt="facebook"></img>Sign in with Facebook
                                    </button>
                                    <button className="btn-social p-1" >
                                    <img className="mx-2 mb-1" src={google} alt="google"></img>Sign in with Google</button>
                </div>
            </Form>
            <p className="text-center mb-5">Forgot Password?</p>
        </div>
    </div>
    

    return (
        <>
        <div className="Post-mobile">


                <div className="outer-post-mobile">
                    <img src={bg1} alt="bg-img"></img>
                    <div className="inner-box">
                        <div className="type d-flex">
                            <i class="uil uil-pen px-1"></i>
                            <p>Article</p>
                        </div>
                        <div className="questions d-flex">
                            <p>What if famous brands had regular fonts? Meet RegulaBrands!</p>
                            <div className="ml-auto">
                                    
                                    <div class="dropdown">
                                    <i class="uil uil-elipsis-double-v-alt drop p-2"></i>
                                    <div class="dropdown-content mt-2">
                                        <a >Edit</a>
                                        <a >Report</a>
                                        <a >Option 3</a>
                                    </div>
                            </div>
                                    
                            </div>
                            
                        </div>
                        <div className="para">
                            <p>I’ve worked in UX for the better part of a decade. From now on, I plan to rei…</p>
                        </div>
                        <div className="mt-4 foot d-flex">
                            <div className="pfp-box d-flex">
                                <img src={pfp} alt="pfp"></img>
                                <p>Sarthak Kamra</p>
                            </div>
                            <div className="views d-flex ml-auto mr-5">
                            <i class="uil uil-eye"></i>
                            <p>1.4k Views</p>
                            </div>
                            <div className="share  p-1 pl-2">Share
                            <i class="uil uil-share p-1"></i>
                            </div>
                        </div>
                    </div>
                </div>

                <div className="middle-bg">

                </div>

                <div className="outer-post-mobile">
                    <img src={bg2} alt="bg-img"></img>
                    <div className="inner-box">
                        <div className="type d-flex">
                            <i class="uil uil-pen px-1"></i>
                            <p>Article</p>
                        </div>
                        <div className="questions d-flex">
                            <p>Tax Benefits for Investment under National Pension Scheme launched by Government</p>
                            <div className="ml-auto">
                                    
                                    <div class="dropdown">
                                    <i class="uil uil-elipsis-double-v-alt drop p-2"></i>
                                    <div class="dropdown-content mt-2">
                                        <a >Edit</a>
                                        <a >Report</a>
                                        <a >Option 3</a>
                                    </div>
                            </div>
                                    
                            </div>
                            
                        </div>
                        <div className="para">
                            <p>I’ve worked in UX for the better part of a decade. From now on, I plan to rei…</p>
                        </div>
                        <div className="mt-4 foot d-flex">
                            <div className="pfp-box d-flex">
                                <img src={pfp2} alt="pfp"></img>
                                <p>Sara West</p>
                            </div>
                            <div className="views d-flex ml-auto mr-5">
                            <i class="uil uil-eye"></i>
                            <p>1.4k Views</p>
                            </div>
                            <div className="share  p-1 pl-2">Share
                            <i class="uil uil-share p-1"></i>
                            </div>
                        </div>
                    </div>
                </div>
                <div className="middle-bg">

                </div>

                <div className="outer-post-mobile">
                    <img src={bg3} alt="bg-img"></img>
                    <div className="inner-box">
                        <div className="type d-flex">
                        <i class="uil uil-calender px-1"></i>
                            <p>Meetup</p>
                        </div>
                        <div className="questions d-flex">
                            <p>Finance & Investment Elite Social Mixer @Lujiazui</p>
                            <div className="ml-auto">
                                    
                                    <div class="dropdown">
                                    <i class="uil uil-elipsis-double-v-alt drop p-2"></i>
                                    <div class="dropdown-content mt-2">
                                        <a >Edit</a>
                                        <a >Report</a>
                                        <a >Option 3</a>
                                    </div>
                            </div>
                                    
                            </div>
                            
                        </div>

                        <div className="calender mb-2 d-flex">
                            <div className="calender-left d-flex">
                                <i class="uil uil-schedule mr-1"></i>
                                <p className="">Fri, 12 Oct, 2018</p>    
                            </div>
                            <div className="calender-mid mx-auto d-flex">
                            <i class="uil uil-location-pin-alt"></i>
                            <p className="fw-bold">Ahmedabad, India</p>    
                            </div>

                        </div>

                        <p className="visit mx-auto">Visit Website</p>
                        <div className="mt-4 foot d-flex">
                            <div className="pfp-box d-flex">
                                <img src={pfp3} alt="pfp"></img>
                                <p>Sara West</p>
                            </div>
                            <div className="views d-flex ml-auto mr-5">
                            <i class="uil uil-eye"></i>
                            <p>1.4k Views</p>
                            </div>
                            <div className="share  p-1 pl-2">Share
                            <i class="uil uil-share p-1"></i>
                            </div>
                        </div>
                    </div>
                </div>
                <div className="middle-bg">
                </div>

                <div className="outer-post-mobile">
                    <div className="inner-box">
                        <div className="type d-flex">
                        <i class="uil uil-bag-alt px-1"></i>
                            <p>Job</p>
                        </div>
                        <div className="questions d-flex">
                            <p>Software Developer</p>
                            <div className="ml-auto">
                                    
                                    <div class="dropdown">
                                    <i class="uil uil-elipsis-double-v-alt drop p-2"></i>
                                    <div class="dropdown-content mt-2">
                                        <a >Edit</a>
                                        <a >Report</a>
                                        <a >Option 3</a>
                                    </div>
                            </div>
                                    
                            </div>
                            
                        </div>

                        <div className="calender mb-2 d-flex">
                            <div className="calender-left d-flex">
                            <i class="uil uil-suitcase-alt"></i>
                                <p className="fw-bold">Innovaccer Analytics Private Ltd.</p>    
                            </div>
                            <div className="calender-mid mx-auto d-flex">
                            <i class="uil uil-location-pin-alt"></i>
                            <p className="fw-bold">Noida, India</p>    
                            </div>

                        </div>

                        <p className="apply mx-auto">Apply on Timesjobs</p>
                        <div className="mt-4 foot d-flex">
                            <div className="pfp-box d-flex">
                                <img src={pfp4} alt="pfp"></img>
                                <p>Joseph Gray</p>
                            </div>
                            <div className="views d-flex ml-auto mr-5">
                            <i class="uil uil-eye"></i>
                            <p>1.7k Views</p>
                            </div>
                            <div className="share  p-1 pl-2">Share
                            <i class="uil uil-share p-1"></i>
                            </div>
                        </div>
                    </div>
                </div>
                <div className="middle-bg">

                </div>

                <div className="edit" onClick={ () => setShow(true)}  >
                    <i class="uil uil-pen" ></i>
                </div>
            </div>


            <div className="mob-fade" style={{ display: showLog | show ? "block" : "none" }}></div>
            <div className="mob-nav" style={{ display: showLog ? "block" : "none" }}>
                {ele}
            </div>
            
            <div className="mob-nav" style={{ display: show ? "block" : "none" }}>
                
                        <div className="modal-inner">
                            <div className="modal-left mx-auto mt-4">
                                <div className="d-flex">
                                    <h3 className="mb-4 mr-auto">Create Account</h3>
                                    <i class="uil uil-times ml-auto cross" onClick={ () => setShow(false)}></i>
                                </div>
                            <Form inline className="mx-auto modal-form mb-4">
                                <div className="sign-form-2 mb-3">
                                    <div className="sign-form-sign">
                                        <input placeholder="First Name">
                                        </input>
                                        <input placeholder="Last Name">
                                        </input>
                                    </div>
                                    <input placeholder="Email">
                                    </input>
                                    <input placeholder="Password">
                                    </input>
                                    <input password placeholder="Confirm Password">
                                    </input>
                                    <i class="uil uil-eye"></i>
                                    <div className="d-flex my-3">
                                        <button className="btn-signin  px-3 py-2 mr-auto" >Create Account </button>
                                        <a className="ml-auto mt-2" onClick={ () => { setShow(false); setShowLog(true)} } >or, Sign In</a>
                                    </div>
                                    <button className="btn-social mt-2 mb-3 p-1">
                                        <img className="mx-2 mb-1" src={facebook} alt="facebook"></img>Sign in with Facebook
                                    </button>
                                    <button className="btn-social p-1" >
                                    <img className="mx-2 mb-1" src={google} alt="google"></img>Sign in with Google</button>
                                </div>
                            </Form>
                    <p className="text-center mb-5">By signing up, you agree to our Terms & conditions, Privacy policy</p>
                    </div>
                </div>
            </div> 
        </>
    )
}

export default PostMobile
