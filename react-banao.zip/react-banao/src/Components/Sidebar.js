import React from 'react'
import './Sidebar.css'
import {Form} from 'react-bootstrap'
import recc from '../Images/rec.png'
import gr1 from '../Images/gr1.png'
import gr2 from '../Images/gr2.png'
import gr3 from '../Images/gr3.png'
import gr4 from '../Images/gr4.png'

function Sidebar(props) {

    const [show1, setShow1] = React.useState(false)
    const [show2, setShow2] = React.useState(false)
    const [show3, setShow3] = React.useState(false)
    const [show4, setShow4] = React.useState(false)
    let ele1;
    if(show1){
        ele1 = <button className="ml-auto mr-2 followed" onClick={ () => setShow1(false)}>Followed</button>    
    }
    let ele2;
    if(show2){
        ele2 = <button className="ml-auto mr-2 followed" onClick={ () => setShow2(false)}>Followed</button>    
    }
    let ele3;
    if(show3){
        ele3 = <button className="ml-auto mr-2 followed" onClick={ () => setShow3(false)}>Followed</button>    
    }
    let ele4;
    if(show4){
        ele4 = <button className="ml-auto mr-2 followed" onClick={ () => setShow4(false)}>Followed</button>    
    }

    let rec;
    if(props.groups){
        rec = 
        <div>
            <div className="rec-outer mt-4">
                <p className="ml-2">
                    <img src={recc} alt="recommended" className="mr-2"></img>
                    RECOMMENDED GROUPS
                </p>
                <div className="rec-group my-2">
                    <img src={gr1} alt="Group1"></img>
                    <p className="ml-4 ">Leisure</p>
                    {ele1}
                    <button className="ml-auto mr-2 follow" onClick={ () => setShow1(true)} style={{ display: show1 ? "none" : "block" }} >Follow</button>
                </div>
                <div className="rec-group my-2">
                    <img src={gr2} alt="Group1"></img>
                    <p className="ml-4 ">Activism</p>
                    {ele2}
                    <button className="ml-auto mr-2 follow" onClick={ () => setShow2(true)} style={{ display: show2 ? "none" : "block" }} >Follow</button>
                </div>
                <div className="rec-group my-2">
                    <img src={gr3} alt="Group1"></img>
                    <p className="ml-4 ">MBA</p>
                    {ele3}
                    <button className="ml-auto mr-2 follow" onClick={ () => setShow3(true)} style={{ display: show3 ? "none" : "block" }} >Follow</button>
                </div>
                <div className="rec-group my-2">
                    <img src={gr4} alt="Group1"></img>
                    <p className="ml-4 ">Philosophy</p>
                    {ele4}
                    <button className="ml-auto mr-2 follow" onClick={ () => setShow4(true)} style={{ display: show4 ? "none" : "block" }} >Follow</button>
                </div>
            </div>
            <p className="mt-5 text-right see-more"> See More...</p>
        </div>
    }

    return (
        
<div className=" px-1 ml-auto sidebar">
            <div className="location my-5 ">
                <Form inline className="">
                    <div className="location-inner">
                    <i class="uil uil-location-pin-alt"></i>
                    <input placeholder=" Enter your location" className="mb-2">
                    </input>
                    <i class="uil uil-pen mt-5"></i>
            </div>
            
    </Form>   
            </div>
            <div className="info  d-flex">
            <i class="uil uil-info-circle mx-2"></i>
            <p>Your location will help us serve  better <br></br> and extend a personalised experience.</p>
            </div>
            {rec}
        </div>
        
        
    )
}

export default Sidebar
