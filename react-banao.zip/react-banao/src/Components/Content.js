import React from 'react'
import './Content.css'
import join from '../Images/join.png'
import leave from '../Images/leave.png'
import down from '../Images/down.png'
import Posts from './Posts'
import PostMobile from './PostMobile'
import Sidebar from './Sidebar'
import {NavDropdown} from 'react-bootstrap'
//import {Navbar} from 'react-bootstrap'

function Content() {

    const [show, setShow] = React.useState(false)
    let ele;
    if(show){
        ele = <div className="leave ml-3 px-3" onClick={ () => setShow(false)} >
                <img src={leave} alt="Join" className="mr-2 mb-1"></img>
                    Leave Group
                </div>
        
        
    }
    return (
        // <Navbar >
        <div className="content" >
            <div className="content-nav ">
                <ul>
                    <li>All Posts(32)</li>
                    <li>Article</li>
                    <li>Event</li>
                    <li>Education</li>
                    <li>Job</li>
                </ul>
                <div className="write-post ml-auto">Write a post
                <img src={down} alt="Join" className="mx-1 pl-3"></img>
                </div>
                {ele}
                <div className="join ml-3 px-3 " onClick={ () => setShow(true)} style={{ display: show ? "none" : "block" }} >
                <img src={join} alt="Join" className="mr-2 mb-1" ></img>
                    Join Group
                </div>
            </div>

            <div className="content-nav-mob mt-3 ml-3 ">
                    <p>All Posts(32)</p>

                    <div className="ml-auto mr-4 filter-mob">
                    <NavDropdown title="Filter" id="basic-nav-dropdown" className="">
                        <NavDropdown.Item >Article</NavDropdown.Item>
                        <NavDropdown.Item >Event</NavDropdown.Item>
                        <NavDropdown.Item >Education</NavDropdown.Item>
                        <NavDropdown.Item >Job</NavDropdown.Item>
                    </NavDropdown>
                    </div>
                    
            </div>



            <div className="d-flex">
                <Posts/>
                <PostMobile/>
                <Sidebar
                groups = {show}/>
            </div>
        </div>
        //</Navbar>
    )
}

export default Content
